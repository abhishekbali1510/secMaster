import React, { useEffect, useState } from 'react';
import '../Style.css';
import { Link } from 'react-router-dom';
import logo from '../images/ivpLogo.png'
import { Container, Box, Grid } from '@mui/material';
function Navbar() {
    const [styleEquity, setStyleEquity] = useState("");
    const [styleBond, setStyleBond] = useState("");
    const [styleBondTable, setStyleBondTable] = useState("");
    const [styleEquityTable, setStyleEquityTable] = useState("");
    

    function fun() {
        setTimeout(() => {
            if (window.location.pathname === "/Bond") {

                setStyleBond("Under");
                setStyleEquity("NoUnder");
                setStyleBondTable("NoUnder");
                setStyleEquityTable("NoUnder");

            }
            else if (window.location.pathname === "/Equity"){
                setStyleEquity("Under");
                setStyleBond("NoUnder");
                setStyleBondTable("NoUnder");
                setStyleEquityTable("NoUnder");
            }
            else if (window.location.pathname === "/BondTable"){
                setStyleEquity("NoUnder");
                setStyleBond("NoUnder");
                setStyleBondTable("Under");
                setStyleEquityTable("NoUnder");
            }
            else if (window.location.pathname === "/EquityTable"){
                setStyleEquity("NoUnder");
                setStyleBond("NoUnder");
                setStyleBondTable("NoUnder");
                setStyleEquityTable("Under");
            }
            // console.log((window.location.pathname));
        }, 200);

    };
    useEffect(() => {
        fun();
    }, []);
    return (
        <div>
            <Container sx={{ backgroundColor: 'primary.dark', margin: "5px 0px", padding: "2px" }}>
                <Grid container columnSpacing={5} alignItems='center'>
                    <Grid item>
                        <img src={logo} width="70px" alt="ivp logo" />
                    </Grid>
                    <Grid item>
                        <Link onClick={fun} className={styleEquity} to="/Equity" style={{ color: "black" }} >
                            <Box className="navbar-component">Equity</Box>
                        </Link>
                    </Grid>
                    <Grid item>
                        <Link onClick={fun} className={styleBond} to="/Bond" >
                            <Box className="navbar-component">Bonds</Box>
                        </Link>
                    </Grid>
                    <Grid item>
                        <Link onClick={fun} className={styleBondTable} to="/BondTable" >
                            <Box className="navbar-component">All Bonds</Box>
                        </Link>
                    </Grid>
                    <Grid item>
                        <Link onClick={fun} className={styleEquityTable} to="/EquityTable" >
                            <Box className="navbar-component">All Equities</Box>
                        </Link>
                    </Grid>
                </Grid>
            </Container>

        </div>
    )
}

export default Navbar
