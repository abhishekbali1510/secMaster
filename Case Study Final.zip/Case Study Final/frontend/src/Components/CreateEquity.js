import React from 'react';
import { useState } from 'react';
import { Button, Container, Grid } from '@mui/material';
import axios from 'axios';

function CreateEquity(props) {
    const [newEquity, setNewEquity] = useState({
        "securityName": "",
        "securityDescription": "",
        "hasPosition": false ,
        "isActiveSecurity": false,
        "lotSize": 0,
        "bbgUniqueName": "",
        "cusip": "",
        "isin": "",
        "sedol": "",
        "bloombergTicker": "",
        "bloombergUniqueId": "",
        "bbgGlobalId": "",
        "tickerAndExchange": "",
        "isAdrFlag": false,
        "adrUnderlyingTicker": "",
        "adrUnderlyingCurrency": "",
        "sharesPerAdr": "",
        "ipoDate": "",
        "pricingCurrency": "",
        "settleDays": 0,
        "totalSharesOutstanding": 0,
        "votingRightsPerShare": 0,
        "averageVolume20d": 0,
        "beta": 0,
        "shortInterest": 0,
        "returnYtd": 0,
        "volatility90d": 0,
        "pfAssetClass": "",
        "pfCountry": "",
        "pfCreditRating": "",
        "pfCurrency": "",
        "pfInstrument": "",
        "pfLiquidityProfile": "",
        "pfMaturity": "",
        "pfNaicsCode": "",
        "pfRegion": "",
        "pfSector": "",
        "pfSubAssetClass": "",
        "countryOfIssuance": "",
        "exchange": "",
        "issuer": "",
        "issueCurrency": "",
        "tradingCurrency": "",
        "bbgIndustrySubGroup": "",
        "bloombergIndustryGroup": "",
        "bloombergSector": "",
        "countryOfIncorporation": "",
        "riskCurrency": "",
        "openPrice": 0,
        "closePrice": 0,
        "volume": 0,
        "lastPrice": 0,
        "askPrice": 0,
        "bidPrice": 0,
        "peRatio": 0,
        "dividendDeclaredDate": "",
        "dividendExDate": "",
        "dividendRecordDate": "",
        "dividendPayDate": "",
        "dividendAmount": 0,
        "frequency": "",
        "dividendType": "",
});
function sendData(){
    console.log(newEquity);
    if(newEquity.securityName==="")
    alert("pleast Enter Security Name");
    else if(newEquity.securityDescription==="")
    alert("pleast Enter Security Description");
    else{
    axios.post("http://localhost:5081/Equitycontroller/create",newEquity).then((response)=>{
        console.log(response);
        if(response.data==="Already exists")
        alert("Equity Already Exist")
        else
        {alert("Equity Created");
        props.SetOpen(false);}
    })}
}
    return (
        <div>
            <Container sx={{ p: '10px', backgroundColor: "white" }}>
                <Grid container alignItems="center" rowSpacing={5}>
                    <Grid item xs={11} sm={11} md={11} lg={11} xl={11}>
                        <h2 style={{ textAlign: "center" }}>New Equity</h2>
                    </Grid>
                    <Grid item xs={1} sm={1} md={1} lg={1} xl={1} >
                        <button style={{ fontSize: "xx-large", background: "transparent", border: "none" }} onClick={() => props.SetOpen(false)}>X</button>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Security Name : </b></label>
                        <input type='text' value={newEquity.securityName} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, securityName: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Security Description : </b></label>
                        <input type='text' value={newEquity.securityDescription} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, securityDescription: e.target.value }
                        })}}   ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Has Position : </b></label>
                        <input type='radio' onChange={()=>{
                            setNewEquity(prevState => {
                                return { ...prevState, hasPosition:true }
                        })}}  name='hasPosition' checked={newEquity.hasPosition===true?true:false} ></input>
                        <label>Yes</label>
                        <input type='radio' onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, hasPosition: false }
                        })}}  name='hasPosition' checked={newEquity.hasPosition===false?true:false} ></input>
                        <label>NO</label>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Is Active : </b></label>
                        <input type='radio' name='isActive' checked={newEquity.isActiveSecurity?true:false} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, isActiveSecurity: true }
                        })}}   ></input>
                        <label>Yes</label>
                        <input type='radio' name='isActive' checked={newEquity.isActiveSecurity?false:true} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, isActiveSecurity: false }
                        })}}  ></input>
                        <label>NO</label>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Round Lot Size : </b></label>
                        <input type='number'value={newEquity.lotSize} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, lotSize: Number(e.target.value) }
                        })}}   ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bloomberg Unique Name : </b></label>
                        <input type='text'value={newEquity.bbgUniqueName} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, bbgUniqueName: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>CUSIP : </b></label>
                        <input type='text' value={newEquity.cusip} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, cusip: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>ISIN : </b></label>
                        <input type='text' value={newEquity.isin} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, isin: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>SEDOL : </b></label>
                        <input type='text' value={newEquity.sedol} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, sedol: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bloomberg Ticker : </b></label>
                        <input type='text' value={newEquity.bloombergTicker} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, bloombergTicker: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bloomberg Unique ID : </b></label>
                        <input type='text' value={newEquity.bloombergUniqueId} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, bloombergUniqueId: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bloomberg Global ID : </b></label>
                        <input type='text' value={newEquity.bbgGlobalId} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, bbgGlobalId: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bloomberg Ticker And Exchange : </b></label>
                        <input type='text' value={newEquity.bloombergTicker} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, bloombergTicker: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Is ADR : </b></label>
                        <input type='radio' name='isADR' checked={newEquity.isAdrFlag?true:false} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, isAdrFlag:true }
                        })}}  ></input>
                        <label>Yes</label>
                        <input type='radio' name='isADR' checked={newEquity.isAdrFlag?false:true} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, isAdrFlag: false }
                        })}} ></input>
                        <label>NO</label>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>ADR Underlying Ticker : </b></label>
                        <input type='text' value={newEquity.adrUnderlyingTicker} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, adrUnderlyingTicker: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>ADR Underlying Currency : </b></label>
                        <input type='text' value={newEquity.adrUnderlyingCurrency} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, adrUnderlyingCurrency: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Shares Per ADR : </b></label>
                        <input type='number' value={newEquity.sharesPerAdr} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, sharesPerAdr: Number(e.target.value) }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>IPO Date : </b></label>
                        <input type='date' value={newEquity.ipoDate} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, ipoDate: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Price Currency : </b></label>
                        <input type='text' value={newEquity.pricingCurrency} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, pricingCurrency: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Settle Days : </b></label>
                        <input type='number' value={newEquity.settleDays} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, settleDays: Number(e.target.value) }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Shares Outstanding : </b></label>
                        <input type='number' value={newEquity.totalSharesOutstanding} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, totalSharesOutstanding: Number(e.target.value) }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Voting Rights Per Share : </b></label>
                        <input type='number' value={newEquity.votingRightsPerShare} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, votingRightsPerShare: Number(e.target.value) }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>20 Day Average Volume : </b></label>
                        <input type='number' value={newEquity.averageVolume20d} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, averageVolume20d: Number(e.target.value) }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Beta : </b></label>
                        <input type='number' value={newEquity.beta} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, beta: Number(e.target.value) }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Short Interest : </b></label>
                        <input type='number' value={newEquity.shortInterest} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, shortInterest: Number(e.target.value) }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>YTD Return : </b></label>
                        <input type='number' value={newEquity.returnYtd} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, returnYtd: Number(e.target.value) }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>90 Day Price Volatility : </b></label>
                        <input type='number' value={newEquity.volatility90d} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, volatility90d: Number(e.target.value) }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Asset Class : </b></label>
                        <input type='text' value={newEquity.pfAssetClass} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, pfAssetClass: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Country : </b></label>
                        <input type='text' value={newEquity.pfCountry} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, pfCountry: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Credit Rating : </b></label>
                        <input type='text' value={newEquity.pfCreditRating} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, pfCreditRating: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Currency : </b></label>
                        <input type='text' value={newEquity.pfCurrency} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, pfCurrency: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Instrument : </b></label>
                        <input type='text' value={newEquity.pfInstrument} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, pfInstrument: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Liquidity Profile : </b></label>
                        <input type='text' value={newEquity.pfLiquidityProfile} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, pfLiquidityProfile: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Maturity : </b></label>
                        <input type='text' value={newEquity.pfMaturity} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, pfMaturity: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF NAICS Code : </b></label>
                        <input type='text' value={newEquity.pfNaicsCode} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, pfNaicsCode: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Region : </b></label>
                        <input type='text' value={newEquity.pfRegion} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, pfRegion: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Sector : </b></label>
                        <input type='text' value={newEquity.pfSector} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, pfSector: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Sub Asset Class : </b></label>
                        <input type='text' value={newEquity.pfSubAssetClass} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, pfSubAssetClass: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Issue Country : </b></label>
                        <input type='text' value={newEquity.countryOfIssuance} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, countryOfIssuance: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Exchange : </b></label>
                        <input type='text' value={newEquity.exchange} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, exchange: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Issuer : </b></label>
                        <input type='text' value={newEquity.issuer} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, issuer: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Issue Currency : </b></label>
                        <input type='text' value={newEquity.issueCurrency} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, issueCurrency: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Trading Currency : </b></label>
                        <input type='text' value={newEquity.tradingCurrency} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, tradingCurrency: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bloomberg Industry Sub Group : </b></label>
                        <input type='text' value={newEquity.bbgIndustrySubGroup} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, bbgIndustrySubGroup: e.target.value }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bloomberg Industry Group : </b></label>
                        <input type='text' value={newEquity.bloombergIndustryGroup} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, bloombergIndustryGroup: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bloomberg Industry Sector : </b></label>
                        <input type='text' value={newEquity.bloombergSector} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, bloombergSector: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Country of Incorporation : </b></label>
                        <input type='text' value={newEquity.countryOfIncorporation} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, countryOfIncorporation: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Risk Currency : </b></label>
                        <input type='text' value={newEquity.riskCurrency} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, riskCurrency: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Open Price : </b></label>
                        <input type='number' value={newEquity.openPrice} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, openPrice: Number(e.target.value) }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Close Price : </b></label>
                        <input type='number' value={newEquity.closePrice} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, closePrice: Number(e.target.value) }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Volume : </b></label>
                        <input type='number' value={newEquity.volume} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, volume: Number(e.target.value) }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Last Price : </b></label>
                        <input type='number' value={newEquity.lastPrice} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, lastPrice: Number(e.target.value) }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Ask Price : </b></label>
                        <input type='number' value={newEquity.askPrice} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, askPrice: Number(e.target.value) }
                        })}}  ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bid Price : </b></label>
                        <input type='number' value={newEquity.bidPrice} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, bidPrice: Number(e.target.value) }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>PE Ratio : </b></label>
                        <input type='number' value={newEquity.peRatio} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, peRatio: Number(e.target.value) }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Declared Date : </b></label>
                        <input type='date' value={newEquity.dividendDeclaredDate} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, dividendDeclaredDate: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Ex Date : </b></label>
                        <input type='date' value={newEquity.dividendExDate} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, dividendExDate: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Record Date : </b></label>
                        <input type='date' value={newEquity.dividendRecordDate} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, dividendRecordDate: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Pay Date : </b></label>
                        <input type='date' value={newEquity.dividendPayDate} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, dividendPayDate: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Amount : </b></label>
                        <input type='number' value={newEquity.dividendAmount} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, dividendAmount: Number(e.target.value) }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Frequency : </b></label>
                        <input type='text' value={newEquity.frequency} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, frequency: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Dividend Type : </b></label>
                        <input type='text' value={newEquity.dividendType} onChange={(e)=>{
                            setNewEquity(prevState => {
                                return { ...prevState, dividendType: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                       <Button variant='contained' onClick={sendData} fullWidth>Save</Button>
                    </Grid>

                </Grid>
            </Container>
        </div>
    )
}

export default CreateEquity