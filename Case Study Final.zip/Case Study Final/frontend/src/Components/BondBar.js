import React, { useState, useEffect } from 'react'
import axios from 'axios';
import '../Style.css';
import { Container, Box, Grid, TextField, Button, Select, MenuItem, Modal } from '@mui/material';
import CreateBond from './CreateBond';
import UpdateBond from './UpdateBond';
function BondBar() {
    const [open, setOpen] = useState(false);
    const [openUpdate, setOpenUpdate] = useState(false);

    const [styleSecuritySummary, setStyleSecuritySummary] = useState("display");
    const [showSecuritySummary, setShowSecuritySummary] = useState("show");
    const [iconSecuritySummary, setIconSecuritySummary] = useState("-");
    function SecuritySummaryFun() {

        if (styleSecuritySummary === "display") {
            setStyleSecuritySummary("notDisplay");
            setIconSecuritySummary("+")
        }

        else {
            setStyleSecuritySummary("display");
            setIconSecuritySummary("-");
        }

    }
    const [styleSecurityIdentifier, setStyleSecurityIdentifier] = useState("notDisplay");
    const [showSecurityIdentifier, setShowSecurityIdentifier] = useState("show");
    const [iconSecurityIdentifier, setIconSecurityIdentifier] = useState("+");
    function SecurityIdentifierFun() {

        if (styleSecurityIdentifier === "display") {
            setStyleSecurityIdentifier("notDisplay");
            setIconSecurityIdentifier("+")
        }

        else {
            setStyleSecurityIdentifier("display");
            setIconSecurityIdentifier("-");
        }

    }
    const [styleSecurityDetails, setStyleSecurityDetails] = useState("notDisplay");
    const [showSecurityDetails, setShowSecurityDetails] = useState("show");
    const [iconSecurityDetails, setIconSecurityDetails] = useState("+");
    function SecurityDetailsFun() {

        if (styleSecurityDetails === "display") {
            setStyleSecurityDetails("notDisplay");
            setIconSecurityDetails("+")
        }

        else {
            setStyleSecurityDetails("display");
            setIconSecurityDetails("-");
        }

    }
    const [styleRisk, setStyleRisk] = useState("notDisplay");
    const [showRisk, setShowRisk] = useState("show");
    const [iconRisk, setIconRisk] = useState("+");
    function RiskFun() {

        if (styleRisk === "display") {
            setStyleRisk("notDisplay");
            setIconRisk("+")
        }

        else {
            setStyleRisk("display");
            setIconRisk("-");
        }

    }

    const [styleRegulatoryDetails, setStyleRegulatoryDetails] = useState("notDisplay");
    const [showRegulatoryDetails, setShowRegulatoryDetails] = useState("show");
    const [iconRegulatoryDetails, setIconRegulatoryDetails] = useState("+");
    function RegulatoryDetailsFun() {

        if (styleRegulatoryDetails === "display") {
            setStyleRegulatoryDetails("notDisplay");
            setIconRegulatoryDetails("+")
        }

        else {
            setStyleRegulatoryDetails("display");
            setIconRegulatoryDetails("-");
        }

    }

    const [styleReferenceData, setStyleReferenceData] = useState("notDisplay");
    const [showReferenceData, setShowReferenceData] = useState("show");
    const [iconReferenceData, setIconReferenceData] = useState("+");
    function ReferenceDataFun() {

        if (styleReferenceData === "display") {
            setStyleReferenceData("notDisplay");
            setIconReferenceData("+")
        }

        else {
            setStyleReferenceData("display");
            setIconReferenceData("-");
        }

    }
    const [stylePutSchedule, setStylePutSchedule] = useState("notDisplay");
    const [showPutSchedule, setShowPutSchedule] = useState("show");
    const [iconPutSchedule, setIconPutSchedule] = useState("+");
    function PutScheduleFun() {

        if (stylePutSchedule === "display") {
            setStylePutSchedule("notDisplay");
            setIconPutSchedule("+")
        }

        else {
            setStylePutSchedule("display");
            setIconPutSchedule("-");
        }

    }

    const [stylePricingAndAnalytics, setStylePricingAndAnalytics] = useState("notDisplay");
    const [showPricingAndAnalytics, setShowPricingAndAnalytics] = useState("notDisplay");
    const [iconPricingAndAnalytics, setIconPricingAndAnalytics] = useState("+");
    function PricingAndAnalyticsFun() {

        if (stylePricingAndAnalytics === "display") {
            setStylePricingAndAnalytics("notDisplay");
            setIconPricingAndAnalytics("+")
        }

        else {
            setStylePricingAndAnalytics("display");
            setIconPricingAndAnalytics("-");
        }

    }

    const [styleCallSchedule, setStyleCallSchedule] = useState("notDisplay");
    const [showCallSchedule, setShowCallSchedule] = useState("show");
    const [iconCallSchedule, setIconCallSchedule] = useState("+");
    function CallScheduleFun() {

        if (styleCallSchedule === "display") {
            setStyleCallSchedule("notDisplay");
            setIconCallSchedule("+")
        }

        else {
            setStyleCallSchedule("display");
            setIconCallSchedule("-");
        }

    }
    const [bondNameFetch, setBondNameFetch] = useState("");
    const [allBondData, setAllBondData] = useState({});
    const [isUpdate, setIsUpdate] = useState(true);
    const [isDelete, setIsDelete] = useState(true);
    function fetchData() {
        console.log(bondNameFetch);
        let localBondNameFetch = bondNameFetch.replaceAll("/", "%2F");
        axios.get("http://localhost:5081/Bondcontroller/GetByName/" + localBondNameFetch + "")
            .then((response) => {
                console.log("response", response.data[0]);
                if (response.data[0] !== undefined) {
                    setAllBondData(response.data[0]);

                    if (response.data[0].putDate !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                putDate: response.data[0].putDate.substring(0, 10)
                            }
                        });
                    if (response.data[0].callDate !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                callDate: response.data[0].callDate.substring(0, 10)
                            }
                        });
                    if (response.data[0].issueDate !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                issueDate: response.data[0].issueDate.substring(0, 10)
                            }
                        });
                    if (response.data[0].maturity !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                maturity: response.data[0].maturity.substring(0, 10)
                            }
                        });
                    if (response.data[0].lastResetDate !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                lastResetDate: response.data[0].lastResetDate.substring(0, 10)
                            }
                        });
                    if (response.data[0].firstCouponDate !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                firstCouponDate: response.data[0].firstCouponDate.substring(0, 10)
                            }
                        });
                    if (response.data[0].penultimateCouponDate !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                penultimateCouponDate: response.data[0].penultimateCouponDate.substring(0, 10)
                            }
                        });
                    setIsDelete(false);
                    setIsUpdate(false);
                }

                else {
                    alert("not found");
                    setIsDelete(true);
                    setIsUpdate(true);
                    setBondNameFetch(" ");
                    setAllBondData({});
                }

            })
    }
    function deleteBond() {
        console.log("Delete fx ");
        axios.delete("http://localhost:5081/Bondcontroller/remove?bondName=" + allBondData.securityName + "").then((response) => {
            console.log(response);
            alert("Bond Deleted");
            setAllBondData({});
            setTabName("All");
        });
    }

    useEffect(()=>{

        console.log(localStorage.getItem("bondValue"));
        if (localStorage.getItem("bondValue") != null && localStorage.getItem("bondValue") != "") {
            setBondNameFetch(localStorage.getItem("bondValue"));
            let localBondNameFetch = localStorage.getItem("bondValue").replaceAll("/", "%2F");
            axios.get("http://localhost:5081/Bondcontroller/GetByName/" + localBondNameFetch + "")
                .then((response) => {
                    console.log("response", response.data[0]);
                    if (response.data[0] !== undefined) {
                        setAllBondData(response.data[0]);
                        if (response.data[0].putDate !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                putDate: response.data[0].putDate.substring(0, 10)
                            }
                        });
                    if (response.data[0].callDate !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                callDate: response.data[0].callDate.substring(0, 10)
                            }
                        });
                    if (response.data[0].issueDate !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                issueDate: response.data[0].issueDate.substring(0, 10)
                            }
                        });
                    if (response.data[0].maturity !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                maturity: response.data[0].maturity.substring(0, 10)
                            }
                        });
                    if (response.data[0].lastResetDate !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                lastResetDate: response.data[0].lastResetDate.substring(0, 10)
                            }
                        });
                    if (response.data[0].firstCouponDate !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                firstCouponDate: response.data[0].firstCouponDate.substring(0, 10)
                            }
                        });
                    if (response.data[0].penultimateCouponDate !== null)
                        setAllBondData(prevState => {
                            return {
                                ...prevState,
                                penultimateCouponDate: response.data[0].penultimateCouponDate.substring(0, 10)
                            }
                        });
                    setIsDelete(false);
                    setIsUpdate(false);
                }

                else {
                    alert("not found");
                    setIsDelete(true);
                    setIsUpdate(true);
                    setBondNameFetch(" ");
                    setAllBondData({});
                }

            })

                        
            localStorage.clear("equityValue");
        }

    }, []);

    const [tabName, setTabName] = useState("All")
    useEffect(() => {
        switch (tabName) {
            case ("All"): {
                setShowSecuritySummary("show");
                setShowSecurityIdentifier("show");
                setShowSecurityDetails("show");
                setShowRisk("show");
                setShowRegulatoryDetails("show");
                setShowReferenceData("show");
                setShowPutSchedule("show");
                setShowPricingAndAnalytics("show");
                setShowCallSchedule("show");
                setStyleSecuritySummary("display");
                setStyleSecurityIdentifier("notDisplay");
                setStyleSecurityDetails("notDisplay");
                setStyleRisk("notDisplay");
                setStyleRegulatoryDetails("notDisplay");
                setStyleReferenceData("notDisplay");
                setStylePricingAndAnalytics("notDisplay");
                setStyleCallSchedule("notDisplay");
                setStylePutSchedule("notDisplay");
                setIconSecurityIdentifier("+");
                setIconSecurityDetails("+");
                setIconRisk("+");
                setIconRegulatoryDetails("+");
                setIconReferenceData("+");
                setIconPricingAndAnalytics("+");
                setIconCallSchedule("+");
                setIconPutSchedule("+");
            }
                break;
            case ("Security Summary"): {
                setShowSecuritySummary("show");
                setStyleSecuritySummary("display");
                setIconSecuritySummary("-");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("notshow");
                setShowRisk("notshow");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("notshow");
                setShowPricingAndAnalytics("notshow");
                setShowCallSchedule("notshow");
                setShowPutSchedule("notshow");
            }
                break;
            case ("Security Identifier"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("show");
                setIconSecurityIdentifier("-");
                setStyleSecurityIdentifier("display");
                setShowSecurityDetails("notshow");
                setShowRisk("notshow");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("notshow");
                setShowPricingAndAnalytics("notshow");
                setShowCallSchedule("notshow");
                setShowPutSchedule("notshow");
            }
                break;
            case ("Security Details"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("show");
                setIconSecurityDetails("-");
                setStyleSecurityDetails("display");
                setShowRisk("notshow");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("notshow");
                setShowPricingAndAnalytics("notshow");
                setShowCallSchedule("notshow");
                setShowPutSchedule("notshow");
            }
                break;
            case ("Risk"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("notshow");
                setShowRisk("show");
                setIconRisk("-");
                setStyleRisk("display");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("notshow");
                setShowPricingAndAnalytics("notshow");
                setShowCallSchedule("notshow");
                setShowPutSchedule("notshow");
            }
                break;
            case ("Regulatory Details"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("notshow");
                setShowRisk("notshow");
                setShowRegulatoryDetails("show");
                setIconRegulatoryDetails("-");
                setStyleRegulatoryDetails("display");
                setShowReferenceData("notshow");
                setShowPricingAndAnalytics("notshow");
                setShowCallSchedule("notshow");
                setShowPutSchedule("notshow");
            }
                break;
            case ("Reference Data"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("notshow");
                setShowRisk("notshow");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("show");
                setIconReferenceData("-");
                setStyleReferenceData("display");
                setShowPricingAndAnalytics("notshow");
                setShowCallSchedule("notshow");
                setShowPutSchedule("notshow");
            }
                break;
            case ("Put Schedule"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("notshow");
                setShowRisk("notshow");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("notshow");
                setShowPutSchedule("show");
                setStylePutSchedule("display");
                setIconPutSchedule("-");
                setShowCallSchedule("notshow");
                setShowPricingAndAnalytics("notshow");
            }
                break;
            case ("Pricing And Analytics"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("notshow");
                setShowRisk("notshow");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("notshow");
                setShowPricingAndAnalytics("show");
                setStylePricingAndAnalytics("display");
                setIconPricingAndAnalytics("-");
                setShowCallSchedule("notshow");
                setShowPutSchedule("notshow");
            }
                break;
            case ("Call Schedule"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("notshow");
                setShowRisk("notshow");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("notshow");
                setShowPricingAndAnalytics("notshow");
                setShowCallSchedule("show");
                setShowPutSchedule("notshow");
                setIconCallSchedule("-");
                setStyleCallSchedule("display");
            }
                break;
        }
    }, [tabName]);
    return (
        <div>
            <Container sx={{ backgroundColor: 'primary.dark', padding: "0px", maxWidth: "1150px" }}  >
                <Grid sx={{ padding: "5px" }} container columnSpacing={5} rowSpacing={2} alignItems='center'>
                    <Grid item xl={2} lg={2} md={2} sm={4} xs={6}>
                        <TextField type='text' label='Bond Name' value={bondNameFetch} onChange={(e) => setBondNameFetch(e.target.value)} variant='filled' sx={{ backgroundColor: "White", minWidth: "100px" }}></TextField>
                    </Grid>
                    <Grid item xl={2} lg={2} md={2} sm={4} xs={6}>
                        <Select size='small'
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            defaultValue={"All"}
                            onChange={(e) => setTabName(e.target.value)}
                            fullWidth
                            sx={{ backgroundColor: "White" }}                     >
                            <MenuItem value={"All"}>All</MenuItem>
                            <MenuItem value={"Security Summary"}>Security Summary</MenuItem>
                            <MenuItem value={"Security Identifier"}>Security Idnetifier</MenuItem>
                            <MenuItem value={"Security Details"}>Security Details</MenuItem>
                            <MenuItem value={"Risk"}>Risk</MenuItem>
                            <MenuItem value={"Regulatory Details"}>Regulatory Details</MenuItem>
                            <MenuItem value={"Reference Data"}>Reference Data</MenuItem>
                            <MenuItem value={"Put Schedule"}>Put Schedule</MenuItem>
                            <MenuItem value={"Pricing And Analytics"}>Pricing And Analytics</MenuItem>
                            <MenuItem value={"Call Schedule"}>Call Schedule</MenuItem>
                        </Select>
                    </Grid>
                    <Grid item xl={2} lg={2} md={2} sm={4} xs={6}>
                        <Button disableElevation sx={{
                            backgroundColor: "white", color: "black", marginRight: "125px", '&:hover': {
                                backgroundColor: "#c3bfbf",
                            },
                        }} className="fetchButton" onClick={fetchData} variant="contained">Fetch</Button>
                    </Grid>
                    <Grid item xl={2} lg={2} md={2} sm={4} xs={6}>
                        <Button disableElevation sx={{
                            backgroundColor: "white", color: "black", '&:hover': {
                                backgroundColor: "#c3bfbf",
                            },
                        }} className="fetchButton" onClick={() => { setOpen(true) }} variant="contained">Add Bond</Button>
                    </Grid>
                    <Grid item xl={2} lg={2} md={2} sm={4} xs={6}>
                        <Button disableElevation sx={{
                            backgroundColor: "white", color: "black", '&:hover': {
                                backgroundColor: "#c3bfbf",
                            },
                        }} onClick={() => { setOpenUpdate(true) }} className="fetchButton" disabled={isUpdate} variant="outlined">Update Bond</Button>
                    </Grid>
                    <Grid item xl={2} lg={2} md={2} sm={4} xs={6} >
                        <Button disableElevation sx={{ backgroundColor: "white", color: "black" }} className="fetchButton" onClick={deleteBond} variant="outlined" disabled={isDelete}>Delete</Button>
                    </Grid>
                </Grid>
                <br />
                {/* -----------Security Summary  */}
                <Container className={showSecuritySummary} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Security Summary</b></Box>
                        <button onClick={SecuritySummaryFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconSecuritySummary}</button>
                    </Box>
                    <br />
                    <Grid className={styleSecuritySummary} container sx={{ backgroundColor: 'white', padding: '5px 10px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Security Description : </b> {allBondData.securityDescription}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Security Name :</b> {allBondData.securityName}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Asset Type :</b> {allBondData.assetType} </Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Investment Type :</b> {allBondData.investmentType} </Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Trading Factor :</b> {allBondData.tradingFactor} </Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Pricing Factor :</b> {allBondData.pricingFactor} </Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Security Identifier  */}
                <Container className={showSecurityIdentifier} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Security Identifier</b></Box>
                        <button onClick={SecurityIdentifierFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconSecurityIdentifier}</button>
                    </Box>
                    <br />
                    <Grid className={styleSecurityIdentifier} container sx={{ backgroundColor: 'white', padding: '15px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>ISIN :</b> {allBondData.isin}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Bloomberg Ticker :</b> {allBondData.bbgTicker}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Bloomberg Unique ID :</b> {allBondData.bbgUniqueId}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>CUSIP :</b>{allBondData.cusip}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>SEDOL :</b>{allBondData.sedol}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Security Deails  */}
                <Container className={showSecurityDetails} sx={{ padding: "10px 5px" }} >
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Security Details</b></Box>
                        <button onClick={SecurityDetailsFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconSecurityDetails}</button>
                    </Box>
                    <br />
                    <Grid className={styleSecurityDetails} container sx={{ backgroundColor: 'white', padding: '15px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>First Coupon Date :</b>{allBondData.firstCouponDate}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Coupon Cap :</b>{allBondData.cap}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Coupon Floor :</b>{allBondData.floor}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Coupon Frequency :</b>{allBondData.couponFrequency}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Coupon Rate :</b>{allBondData.coupon}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Coupon Type :</b>{allBondData.couponType}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Float Spread :</b>{allBondData.spread}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Is Callable :</b>{allBondData.callableFlag ? "Yes" : "No"}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Is Fix to Float :</b>{allBondData.isFixToFloat ? "Yes" : "No"}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Is Putable :</b>{allBondData.putableFlag ? "Yes" : "No"}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Issue Date :</b>{allBondData.issueDate}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Last Reset Date :</b>{allBondData.lastResetDate}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Maturity Date :</b>{allBondData.maturity}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Maximum Call Notice Days :</b>{allBondData.callNotificationMaxDays}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Maximum Put Notice Days :</b>{allBondData.putNotificationMaxDays}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Penultimate Coupon Date : </b>{allBondData.penultimateCouponDate}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Reset Frequency :</b>{allBondData.resetFrequency}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Has Position :</b>{allBondData.hasPosition ? "Yes" : "No"}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Risk  */}
                <Container className={showRisk} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Risk</b></Box>
                        <button onClick={RiskFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconRisk}</button>
                    </Box>
                    <br />
                    <Grid className={styleRisk} container sx={{ backgroundColor: 'white', padding: '5px 10px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Duration :</b>{allBondData.macaulayDuration}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Volatility 30D :</b>{allBondData._30dVolatility}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Volatility 90D :</b>{allBondData._90dVolatility}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Convexity :</b>{allBondData.convexity}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Average Volume 30D :</b>{allBondData._30dayAverageVolume}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Regulatory Details  */}
                <Container className={showRegulatoryDetails} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Regulatory Details</b></Box>
                        <button onClick={RegulatoryDetailsFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconRegulatoryDetails}</button>
                    </Box>
                    <br />
                    <Grid className={styleRegulatoryDetails} container sx={{ backgroundColor: 'white', padding: '5px 10px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Form PF Asset Class :</b>{allBondData.pfAssetClass}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Form PF Country :</b>{allBondData.pfCountry}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Form PF Credit Rating :</b>{allBondData.pfCreditRating}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Form PF Currency :</b>{allBondData.pfCurrency}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Form PF Instrument :</b>{allBondData.pfInstrument}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Form PF Liquidity Profile :</b>{allBondData.pfLiquidityProfile}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Form PF Maturity :</b>{allBondData.pfMaturity}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Form PF NAICS Code :</b>{allBondData.pfNaicsCode}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Form PF Region :</b>{allBondData.pfRegion}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Form PF Sector :</b>{allBondData.pfSector}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Form PF Sub Asset Class :</b>{allBondData.pfSubAssetClass}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Reference Data  */}
                <Container className={showReferenceData} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Reference Data</b></Box>
                        <button onClick={ReferenceDataFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconReferenceData}</button>
                    </Box>
                    <br />
                    <Grid className={styleReferenceData} container sx={{ backgroundColor: 'white', padding: '5px 10px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Bloomberg Industry Group :</b>{allBondData.bloombergIndustryGroup}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Bloomberg Industry Sub
                                Group :</b>{allBondData.bloombergIndustrySubGroup}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Bloomberg Sector :</b>{allBondData.bloombergIndustrySector}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Issue Country :</b>{allBondData.countryOfIssuance}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Issue Currency :</b>{allBondData.issueCurrency}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Issuer :</b>{allBondData.issuer}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Risk Currency :</b>{allBondData.riskCurrency}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Put Schedule  */}
                <Container className={showPutSchedule} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Put Schedule</b></Box>
                        <button onClick={PutScheduleFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconPutSchedule}</button>
                    </Box>
                    <br />
                    <Grid className={stylePutSchedule} container sx={{ backgroundColor: 'white', padding: '5px 10px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Put Date :</b>{allBondData.putDate}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Put Price :</b>{allBondData.putPrice}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Pricing And Analytics  */}
                <Container className={showPricingAndAnalytics} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Pricing And Analytics</b></Box>
                        <button onClick={PricingAndAnalyticsFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconPricingAndAnalytics}</button>
                    </Box>
                    <br />
                    <Grid className={stylePricingAndAnalytics} container sx={{ backgroundColor: 'white', padding: '5px 10px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Ask Price :</b>{allBondData.askPrice}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>High Price :</b>{allBondData.highPrice}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Low Price :</b>{allBondData.lowPrice}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Open Price :</b>{allBondData.openPrice}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Volume :</b>{allBondData.volume}</Box>
                        </Grid>
                        {/* <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Ask Price :</b>{allBondData.pfAssetClass}</Box>
                        </Grid> */}
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Bid Price :</b>{allBondData.bidPrice}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Last Price :</b>{allBondData.lastPrice}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Call Schedule  */}
                <Container className={showCallSchedule} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Call Schedule</b></Box>
                        <button onClick={CallScheduleFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconCallSchedule}</button>
                    </Box>
                    <br />
                    <Grid className={styleCallSchedule} container sx={{ backgroundColor: 'white', padding: '5px 10px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Call Date :</b>{allBondData.callDate}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Call Price :</b>{allBondData.callPrice}</Box>
                        </Grid>
                    </Grid>
                </Container>

            </Container>

            {/* --------modal  */}
            <Modal
                open={open}
                onClose={() => setOpen(false)}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
                sx={{ backgroundColor: "white", margin: "10px", maxHeight: "100%", overflow: "scroll" }}
            >
                <CreateBond SetOpen={setOpen} />
            </Modal>

            <Modal
                open={openUpdate}
                onClose={() => setOpen(false)}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
                sx={{ backgroundColor: "white", margin: "10px", maxHeight: "100%", overflow: "scroll" }}
            >
                <UpdateBond SetOpenUpdate={setOpenUpdate} allBondData={allBondData} SetAllBondData={setAllBondData} />
            </Modal>
        </div>
    )
}

export default BondBar
