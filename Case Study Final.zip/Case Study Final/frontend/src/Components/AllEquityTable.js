import '../Style.css';
import React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import axios from "axios";
import { Container } from '@mui/material';
import { useNavigate } from 'react-router-dom';

function EquityTable() {
    let navigate=useNavigate();
    const [EquityData, setData] = React.useState([]);
    const result = async () => {
        await axios.get("http://localhost:5081/Equitycontroller").then((response) => {
            setData(response.data);
            // console.log("This is message ", response, result);
        });
    };

    React.useEffect(() => {
        result();
    }, []);

    return (
        <Container maxWidth='lg' sx={{ backgroundColor: 'primary.dark' }}>
            <TableContainer component={Paper}>
                <Table sx={{ minWidth: 650 }} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell align="center" sx={{ border: "2px solid #1565c0" }}><h2>Security Name</h2></TableCell>
                            <TableCell align="center" sx={{ border: "2px solid #1565c0" }}><h2>Security Description</h2></TableCell>

                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {/* fragment */}
                        <TableRow style={{ height: "1px", backgroudColor: "#1565c0", zIndex: "2" }}></TableRow>
                        <>
                            {EquityData.map((value, index) => {
                                return (
                                    <TableRow
                                        key={index}>
                                        <TableCell onClick={()=>{
                                            localStorage.setItem("equityValue",value.securityName);
                                            navigate("/Equity");
                                        }} align="center" sx={{
                                            '&:hover': {
                                                backgroundColor: "#c3bfbf",
                                            }, border: "2px solid #1565c0"
                                        }}>
                                            {value.securityName}
                                        </TableCell>
                                        <TableCell align="center" sx={{ border: "2px solid #1565c0" }}>
                                            {value.securityDescription}
                                        </TableCell>

                                    </TableRow>
                                );
                            })}
                        </>
                    </TableBody>
                </Table>
            </TableContainer>
        </Container>
    );
}

export default EquityTable;
