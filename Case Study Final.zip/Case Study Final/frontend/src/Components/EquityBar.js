import React, { useEffect, useState } from 'react'
import axios from 'axios';
import '../Style.css';
import { Container, Box, Grid, TextField, Button, Select, MenuItem, Modal } from '@mui/material';
import CreateEquity from './CreateEquity';
import UpdateEquity from './UpdateEquity';
// import AllEquityFields from './AllEquityFields';
function EquityBar() {
    const [open, setOpen] = useState(false);
    const [openUpdate, setOpenUpdate] = useState(false);

    const [styleSecuritySummary, setStyleSecuritySummary] = useState("display");
    const [ShowSecuritySummary, setShowSecuritySummary] = useState("show");
    const [iconSecuritySummary, setIconSecuritySummary] = useState("-");
    function SecuritySummaryFun() {

        if (styleSecuritySummary === "display") {
            setStyleSecuritySummary("notDisplay");
            setIconSecuritySummary("+")
        }

        else {
            setStyleSecuritySummary("display");
            setIconSecuritySummary("-");
        }

    }
    const [styleSecurityIdentifier, setStyleSecurityIdentifier] = useState("notDisplay");
    const [showSecurityIdentifier, setShowSecurityIdentifier] = useState("show");
    const [iconSecurityIdentifier, setIconSecurityIdentifier] = useState("+");
    function SecurityIdentifierFun() {

        if (styleSecurityIdentifier === "display") {
            setStyleSecurityIdentifier("notDisplay");
            setIconSecurityIdentifier("+")
        }

        else {
            setStyleSecurityIdentifier("display");
            setIconSecurityIdentifier("-");
        }

    }
    const [styleSecurityDetails, setStyleSecurityDetails] = useState("notDisplay");
    const [showSecurityDetails, setShowSecurityDetails] = useState("show");
    const [iconSecurityDetails, setIconSecurityDetails] = useState("+");
    function SecurityDetailsFun() {

        if (styleSecurityDetails === "display") {
            setStyleSecurityDetails("notDisplay");
            setIconSecurityDetails("+")
        }

        else {
            setStyleSecurityDetails("display");
            setIconSecurityDetails("-");
        }

    }
    const [styleRisk, setStyleRisk] = useState("notDisplay");
    const [showRisk, setShowRisk] = useState("show");
    const [iconRisk, setIconRisk] = useState("+");
    function RiskFun() {

        if (styleRisk === "display") {
            setStyleRisk("notDisplay");
            setIconRisk("+")
        }

        else {
            setStyleRisk("display");
            setIconRisk("-");
        }

    }

    const [styleRegulatoryDetails, setStyleRegulatoryDetails] = useState("notDisplay");
    const [showRegulatoryDetails, setShowRegulatoryDetails] = useState("show");
    const [iconRegulatoryDetails, setIconRegulatoryDetails] = useState("+");
    function RegulatoryDetailsFun() {

        if (styleRegulatoryDetails === "display") {
            setStyleRegulatoryDetails("notDisplay");
            setIconRegulatoryDetails("+")
        }

        else {
            setStyleRegulatoryDetails("display");
            setIconRegulatoryDetails("-");
        }

    }

    const [styleReferenceData, setStyleReferenceData] = useState("notDisplay");
    const [showReferenceData, setShowReferenceData] = useState("show");
    const [iconReferenceData, setIconReferenceData] = useState("+");
    function ReferenceDataFun() {

        if (styleReferenceData === "display") {
            setStyleReferenceData("notDisplay");
            setIconReferenceData("+")
        }

        else {
            setStyleReferenceData("display");
            setIconReferenceData("-");
        }

    }

    const [stylePricingDetails, setStylePricingDetails] = useState("notDisplay");
    const [showPricingDetails, setShowPricingDetails] = useState("show");
    const [iconPricingDetails, setIconPricingDetails] = useState("+");
    function PricingDetailsFun() {

        if (stylePricingDetails === "display") {
            setStylePricingDetails("notDisplay");
            setIconPricingDetails("+")
        }

        else {
            setStylePricingDetails("display");
            setIconPricingDetails("-");
        }

    }

    const [styleDividentHistory, setStyleDividentHistory] = useState("notDisplay");
    const [showDividentHistory, setShowDividentHistory] = useState("show");
    const [iconDividentHistory, setIconDividentHistory] = useState("+");
    function DividentHistoryFun() {

        if (styleDividentHistory === "display") {
            setStyleDividentHistory("notDisplay");
            setIconDividentHistory("+")
        }

        else {
            setStyleDividentHistory("display");
            setIconDividentHistory("-");
        }

    }
    const [equityNameFetch, setEquityNameFetch] = useState("");
    const [allEquityData, setAllEquityData] = useState({});
    const [isDelete, setIsDelete] = useState(true);
    const [isUpdate, setIsUpdate] = useState(true);
    function fetchData() {
        console.log(equityNameFetch);
        let localEquityNameFetch = equityNameFetch.replaceAll("/", "%2F");
        axios.get("http://localhost:5081/Equitycontroller/GetByName/" + localEquityNameFetch + "")
            .then((response) => {
                console.log("response", response.data[0]);
                if (response.data[0] !== undefined) {
                    setAllEquityData(response.data[0]);
                    if (response.data[0].dividendDeclaredDate !== null)
                    setAllEquityData(prevState => {
                        return {
                            ...prevState,
                            dividendDeclaredDate: response.data[0].dividendDeclaredDate.substring(0, 10),
                        }
                    });
                if (response.data[0].dividendExDate !== null)
                    setAllEquityData(prevState => {
                        return {
                            ...prevState,
                            dividendExDate: response.data[0].dividendExDate.substring(0, 10),
                        }
                    });
                if (response.data[0].dividendPayDate !== null)
                    setAllEquityData(prevState => {
                        return {
                            ...prevState,
                            dividendPayDate: response.data[0].dividendPayDate.substring(0, 10),
                        }
                    });
                if (response.data[0].ipoDate !== null)
                    setAllEquityData(prevState => {
                        return {
                            ...prevState,
                            ipoDate: response.data[0].ipoDate.substring(0, 10)
                        }
                    });
                if (response.data[0].dividendRecordDate !== null)
                    setAllEquityData(prevState => {
                        return {
                            ...prevState,
                            dividendRecordDate: response.data[0].dividendRecordDate.substring(0, 10),
                        }
                    });
                    setIsDelete(false);
                    setIsUpdate(false);
                }

                else {
                    alert("not found");
                    setIsDelete(true);
                    setIsUpdate(true);
                    setEquityNameFetch(" ");
                    setAllEquityData({});
                }
            })
    }
    const [tabName, setTabName] = useState("All");
    function deleteEquity() {
        console.log("Delete fx ");
        axios.delete("http://localhost:5081/Equitycontroller/remove?equityName=" + allEquityData.securityName + "").then((response) => {
            console.log(response);
            alert("Equity Deleted");
            setAllEquityData({});
            setTabName("All");
        });

    }

    useEffect(() => {
        switch (tabName) {
            case ("All"): {
                setShowSecuritySummary("show");
                setShowSecurityIdentifier("show");
                setShowSecurityDetails("show");
                setShowRisk("show");
                setShowRegulatoryDetails("show");
                setShowReferenceData("show");
                setShowPricingDetails("show");
                setShowDividentHistory("show");
                setStyleSecuritySummary("display");
                setStyleSecurityIdentifier("notDisplay");
                setStyleSecurityDetails("notDisplay");
                setStyleRisk("notDisplay");
                setStyleRegulatoryDetails("notDisplay");
                setStyleReferenceData("notDisplay");
                setStylePricingDetails("notDisplay");
                setStyleDividentHistory("notDisplay");
                setIconSecurityIdentifier("+");
                setIconSecurityDetails("+");
                setIconRisk("+");
                setIconRegulatoryDetails("+");
                setIconReferenceData("+");
                setIconPricingDetails("+");
                setIconDividentHistory("+");
            }
                break;
            case ("Security Summary"): {
                setShowSecuritySummary("show");
                setStyleSecuritySummary("display");
                setIconSecuritySummary("-");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("notshow");
                setShowRisk("notshow");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("notshow");
                setShowPricingDetails("notshow");
                setShowDividentHistory("notshow");
            }
                break;
            case ("Security Identifier"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("show");
                setIconSecurityIdentifier("-");
                setStyleSecurityIdentifier("display");
                setShowSecurityDetails("notshow");
                setShowRisk("notshow");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("notshow");
                setShowPricingDetails("notshow");
                setShowDividentHistory("notshow");
            }
                break;
            case ("Security Details"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("show");
                setIconSecurityDetails("-");
                setStyleSecurityDetails("display");
                setShowRisk("notshow");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("notshow");
                setShowPricingDetails("notshow");
                setShowDividentHistory("notshow");
            }
                break;
            case ("Risk"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("notshow");
                setShowRisk("show");
                setIconRisk("-");
                setStyleRisk("display");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("notshow");
                setShowPricingDetails("notshow");
                setShowDividentHistory("notshow");
            }
                break;
            case ("Regulatory Details"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("notshow");
                setShowRisk("notshow");
                setShowRegulatoryDetails("show");
                setIconRegulatoryDetails("-");
                setStyleRegulatoryDetails("display");
                setShowReferenceData("notshow");
                setShowPricingDetails("notshow");
                setShowDividentHistory("notshow");
            }
                break;
            case ("Reference Data"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("notshow");
                setShowRisk("notshow");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("show");
                setIconReferenceData("-");
                setStyleReferenceData("display");
                setShowPricingDetails("notshow");
                setShowDividentHistory("notshow");
            }
                break;
            case ("Pricing Details"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("notshow");
                setShowRisk("notshow");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("notshow");
                setShowPricingDetails("show");
                setStylePricingDetails("display");
                setIconPricingDetails("-");
                setShowDividentHistory("notshow");
            }
                break;
            case ("Divident History"): {
                setShowSecuritySummary("notshow");
                setShowSecurityIdentifier("notshow");
                setShowSecurityDetails("notshow");
                setShowRisk("notshow");
                setShowRegulatoryDetails("notshow");
                setShowReferenceData("notshow");
                setShowPricingDetails("notshow");
                setShowDividentHistory("show");
                setIconDividentHistory("-");
                setStyleDividentHistory("display");
            }
                break;
        }
    }, [tabName]);

    useEffect(() => {
        console.log(localStorage.getItem("equityValue"));
        if (localStorage.getItem("equityValue") != null && localStorage.getItem("equityValue") != "") {
            setEquityNameFetch(localStorage.getItem("equityValue"));
            let localEquityNameFetch = localStorage.getItem("equityValue").replaceAll("/", "%2F");
            axios.get("http://localhost:5081/Equitycontroller/GetByName/" + localEquityNameFetch + "")
                .then((response) => {
                    console.log("response", response.data[0]);
                    if (response.data[0] !== undefined) {
                        setAllEquityData(response.data[0]);

                        if (response.data[0].dividendDeclaredDate !== null)
                            setAllEquityData(prevState => {
                                return {
                                    ...prevState,
                                    dividendDeclaredDate: response.data[0].dividendDeclaredDate.substring(0, 10),
                                }
                            });
                        if (response.data[0].dividendExDate !== null)
                            setAllEquityData(prevState => {
                                return {
                                    ...prevState,
                                    dividendExDate: response.data[0].dividendExDate.substring(0, 10),
                                }
                            });
                        if (response.data[0].dividendPayDate !== null)
                            setAllEquityData(prevState => {
                                return {
                                    ...prevState,
                                    dividendPayDate: response.data[0].dividendPayDate.substring(0, 10),
                                }
                            });
                        if (response.data[0].ipoDate !== null)
                            setAllEquityData(prevState => {
                                return {
                                    ...prevState,
                                    ipoDate: response.data[0].ipoDate.substring(0, 10)
                                }
                            });
                        if (response.data[0].dividendRecordDate !== null)
                            setAllEquityData(prevState => {
                                return {
                                    ...prevState,
                                    dividendRecordDate: response.data[0].dividendRecordDate.substring(0, 10),
                                }
                            });
                        setIsDelete(false);
                        setIsUpdate(false);
                    }

                    else {
                        alert("not found");
                        setIsDelete(true);
                        setIsUpdate(true);
                        setEquityNameFetch(" ");
                        setAllEquityData({});
                    }
                })
            localStorage.clear("equityValue");
        }

    }, []);
    return (
        <div>
            <Container sx={{ backgroundColor: 'primary.dark', padding: "0px", maxWidth: "1150px" }}  >
                <Grid sx={{ padding: "5px" }} container columnSpacing={2} rowSpacing={2} alignItems='center'>
                    <Grid item xl={2} lg={2} md={2} sm={4} xs={6}>
                        <TextField type='text' label='Equity Name' onChange={(e) => setEquityNameFetch(e.target.value)} value={equityNameFetch} variant='filled' sx={{ backgroundColor: "White", minWidth: "100px" }}></TextField>
                    </Grid>
                    <Grid item xl={2} lg={2} md={2} sm={4} xs={6}>
                        <Select size='small'
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            onChange={(e) => setTabName(e.target.value)}
                            value={tabName}
                            fullWidth
                            sx={{ backgroundColor: "White" }}                     >
                            <MenuItem value={"All"}>All</MenuItem>
                            <MenuItem value={"Security Summary"}>Security Summary</MenuItem>
                            <MenuItem value={"Security Identifier"}>Security Idnetifier</MenuItem>
                            <MenuItem value={"Security Details"}>Security Details</MenuItem>
                            <MenuItem value={"Risk"}>Risk</MenuItem>
                            <MenuItem value={"Regulatory Details"}>Regulatory Details</MenuItem>
                            <MenuItem value={"Reference Data"}>Reference Data</MenuItem>
                            <MenuItem value={"Pricing Details"}>Pricing Details</MenuItem>
                            <MenuItem value={"Divident History"}>Divident History</MenuItem>
                        </Select>
                    </Grid>
                    <Grid item xl={2} lg={2} md={2} sm={4} xs={6}>
                        <Button disableElevation sx={{
                            backgroundColor: "white", color: "black", '&:hover': {
                                backgroundColor: "#c3bfbf",
                            },
                        }} className="fetchButton" onClick={fetchData} variant="contained">Fetch</Button>
                    </Grid>
                    <Grid item xl={2} lg={2} md={2} sm={4} xs={6}>
                        <Button disableElevation sx={{
                            backgroundColor: "white", color: "black", '&:hover': {
                                backgroundColor: "#c3bfbf",
                            },
                        }} onClick={() => { setOpen(true) }} className="fetchButton" variant="outlined">Add Equity</Button>
                    </Grid>
                    <Grid item xl={2} lg={2} md={2} sm={4} xs={6}>
                        <Button disableElevation sx={{
                            backgroundColor: "white", color: "black", '&:hover': {
                                backgroundColor: "#c3bfbf",
                            },
                        }} onClick={() => { setOpenUpdate(true) }} className="fetchButton" disabled={isUpdate} variant="outlined">Update Equity</Button>
                    </Grid>
                    <Grid item xl={2} lg={2} md={2} sm={4} xs={6} >
                        <Button disableElevation sx={{ backgroundColor: "white", color: "black" }} variant="outlined" onClick={deleteEquity} disabled={isDelete}>Delete</Button>
                    </Grid>
                </Grid>
                <br />
                {/* -----------Security Summary  */}
                <Container className={ShowSecuritySummary} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Security Summary</b></Box>
                        <button onClick={SecuritySummaryFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconSecuritySummary}</button>
                    </Box>
                    <br />
                    <Grid className={styleSecuritySummary} container sx={{ backgroundColor: 'white', padding: '5px 10px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box ><b>Security Name :</b> {allEquityData.securityName}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Security Description :</b>{allEquityData.securityDescription}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Has Position :</b>{allEquityData.hasPosition ? "Yes" : "No"}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Is Active :</b>{allEquityData.isActiveSecurity ? "Yes" : "No"}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Round Lot Size :</b>{allEquityData.lotSize}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Bloomberg Unique Name :</b>{allEquityData.bbgUniqueName}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Security Identifier  */}
                <Container className={showSecurityIdentifier} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Security Identifier</b></Box>
                        <button onClick={SecurityIdentifierFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconSecurityIdentifier}</button>
                    </Box>
                    <br />
                    <Grid className={styleSecurityIdentifier} container sx={{ backgroundColor: 'white', padding: '15px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>CUSIP :</b> {allEquityData.cusip}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>ISIN:</b> {allEquityData.isin}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>SEDOL :</b> {allEquityData.sedol}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Bloomberg Ticker:</b> {allEquityData.bloombergTicker}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Bloomberg Unique ID :</b> {allEquityData.bloombergUniqueId}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Bloomberg Global ID :</b> {allEquityData.bbgGlobalId}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Bloomberg Ticker and
                                Exchange :</b> {allEquityData.bloombergTicker}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Security Details  */}
                <Container className={showSecurityDetails} sx={{ padding: "10px 5px" }} >
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Security Details</b></Box>
                        <button onClick={SecurityDetailsFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconSecurityDetails}</button>
                    </Box>
                    <br />
                    <Grid className={styleSecurityDetails} container sx={{ backgroundColor: 'white', padding: '15px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Is ADR :</b> {allEquityData.isAdr ? "Yes" : "No"}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>ADR Underlying Ticker :</b> {allEquityData.adrUnderlyingTicker}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>ADR Underlying Currency :</b> {allEquityData.adrUnderlyingCurrency}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Shares Per ADR :</b> {allEquityData.sharesPerAdr}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>IPO Date :</b> {allEquityData.ipoDate}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Price Currency :</b> {allEquityData.pricingCurrency}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Settle Days :</b> {allEquityData.settleDays}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Shares Outstanding :</b> {allEquityData.totalSharesOutstanding}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Voting Rights Per Share :</b> {allEquityData.votingRightsPerShare}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Risk  */}
                <Container className={showRisk} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Risk</b></Box>
                        <button onClick={RiskFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconRisk}</button>
                    </Box>
                    <br />
                    <Grid className={styleRisk} container sx={{ backgroundColor: 'white', padding: '5px 10px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>20 Day Average Volume : </b>{allEquityData.averageVolume20d}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Beta :</b> {allEquityData.beta}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Short Interest :</b> {allEquityData.shortInterest}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>YTD Return :</b> {allEquityData.returnYtd}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>90 Day Price Volatility :</b> {allEquityData.volatility90d}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Regulatory Details  */}
                <Container className={showRegulatoryDetails} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Regulatory Details</b></Box>
                        <button onClick={RegulatoryDetailsFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconRegulatoryDetails}</button>
                    </Box>
                    <br />
                    <Grid className={styleRegulatoryDetails} container sx={{ backgroundColor: 'white', padding: '5px 10px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Form PF Asset Class :</b> {allEquityData.pfAssetClass}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Form PF Country :</b> {allEquityData.pfCountry}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Form PF Credit Rating :</b> {allEquityData.pfCreditRating}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Form PF Currency :</b> {allEquityData.pfCurrency}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Form PF Instrument :</b> {allEquityData.pfInstrument}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Form PF Liquidity Profile :</b> {allEquityData.pfLiquidityProfile}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Form PF Maturity :</b> {allEquityData.pfMaturity}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Form PF NAICS Code :</b> {allEquityData.pfNaicsCode}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Form PF Region :</b> {allEquityData.pfRegion}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Form PF Sector :</b> {allEquityData.pfSector}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Form PF Sub Asset Class :</b> {allEquityData.pfSubAssetClass}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Reference Data  */}
                <Container className={showReferenceData} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Reference Data</b></Box>
                        <button onClick={ReferenceDataFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconReferenceData}</button>
                    </Box>
                    <br />
                    <Grid className={styleReferenceData} container sx={{ backgroundColor: 'white', padding: '5px 10px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Issue Country :</b> {allEquityData.countryOfIssuance}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Exchange :</b> {allEquityData.exchange}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Issuer :</b> {allEquityData.issuer}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Issue Currency :</b> {allEquityData.issueCurrency}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Trading Currency :</b> {allEquityData.tradingCurrency}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Bloomberg Industry Sub Group :</b> {allEquityData.bbgIndustrySubGroup}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Bloomberg Industry Group :</b> {allEquityData.bloombergIndustryGroup}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Bloomberg Industry Sector :</b> {allEquityData.bloombergSector}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Country of Incorporation :</b> {allEquityData.countryOfIncorporation}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Risk Currency :</b> {allEquityData.riskCurrency}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Pricing Details  */}
                <Container className={showPricingDetails} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Pricing Details</b></Box>
                        <button onClick={PricingDetailsFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconPricingDetails}</button>
                    </Box>
                    <br />
                    <Grid className={stylePricingDetails} container sx={{ backgroundColor: 'white', padding: '5px 10px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Open Price :</b> {allEquityData.openPrice} </Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Close Price :</b> {allEquityData.closePrice}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Volume :</b> {allEquityData.volume}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Last Price :</b> {allEquityData.lastPrice}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Ask Price :</b> {allEquityData.askPrice}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Bid Price :</b> {allEquityData.bidPrice}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>PE Ratio :</b> {allEquityData.peRatio}</Box>
                        </Grid>
                    </Grid>
                </Container>

                {/* -----------Divident History  */}
                <Container className={showDividentHistory} sx={{ padding: "10px 5px" }}>
                    <Box sx={{ backgroundColor: 'white', padding: '15px', maxWidth: "1024px" }} alignItems='center' maxWidth='md' >
                        <Box sx={{ display: 'inline', fontSize: "20px" }}><b>Divident History</b></Box>
                        <button onClick={DividentHistoryFun} style={{ float: 'right', display: 'inline', fontWeight: 'bolder' }} >{iconDividentHistory}</button>
                    </Box>
                    <br />
                    <Grid className={styleDividentHistory} container sx={{ backgroundColor: 'white', padding: '5px 10px' }} alignItems='center' rowSpacing={2} >
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Declared Date:</b> {allEquityData.dividendDeclaredDate}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Ex Date :</b> {allEquityData.dividendExDate}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Record Date :</b> {allEquityData.dividendRecordDate}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Pay Date :</b> {allEquityData.dividendPayDate}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Amount :</b> {allEquityData.dividendAmount}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Frequency :</b> {allEquityData.frequency}</Box>
                        </Grid>
                        <Grid item xs={6} sm={4} md={4} lg={3}>
                            <Box><b>Dividend Type :</b> {allEquityData.dividendType}</Box>
                        </Grid>
                    </Grid>
                </Container>

            </Container>

            {/* --------modal  */}
            <Modal
                open={open}
                onClose={() => setOpen(false)}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
                sx={{ backgroundColor: "white", margin: "10px", maxHeight: "100%", overflow: "scroll" }}
            >
                <CreateEquity SetOpen={setOpen} />
            </Modal>
            <Modal
                open={openUpdate}
                onClose={() => setOpen(false)}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
                sx={{ backgroundColor: "white", margin: "10px", maxHeight: "100%", overflow: "scroll" }}
            >
                <UpdateEquity SetOpenUpdate={setOpenUpdate} allEquityData={allEquityData} SetAllEquityData={setAllEquityData} />
            </Modal>
        </div>
    )
}

export default EquityBar
