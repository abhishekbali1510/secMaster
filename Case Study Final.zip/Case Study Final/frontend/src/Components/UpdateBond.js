import React, { useState,useEffect } from 'react';
import axios from 'axios';
import { Container, Grid, Button } from '@mui/material';

function UpdateBond(props) {
    const [newBond, setNewBond] = useState(
        {
            "securityDescription": "",
            "securityName": "",
            "assetType": "",
            "investmentType": "",
            "tradingFactor": 0,
            "pricingFactor": 0,
            "isin": "",
            "bbgTicker": "",
            "bbgUniqueId": "",
            "cusip": "",
            "sedol": "",
            "firstCouponDate": "",
            "cap": "",
            "floor": "",
            "couponFrequency": 0,
            "coupon": 0,
            "couponType": "",
            "spread": "",
            "callableFlag": false,
            "fixToFloatFlag": false,
            "putableFlag": false,
            "issueDate": "",
            "lastResetDate": "",
            "maturity": "",
            "callNotificationMaxDays": 0,
            "putNotificationMaxDays": "",
            "penultimateCouponDate": "",
            "resetFrequency": "",
            "hasPosition": false,
            "macaulayDuration": 0,
            "_30dVolatility": 0,
            "_90dVolatility": 0,
            "convexity": 0,
            "_30dayAverageVolume": 0,
            "pfAssetClass": "",
            "pfCountry": "",
            "pfCreditRating": "",
            "pfCurrency": "",
            "pfInstrument": "",
            "pfLiquidityProfile": "",
            "pfMaturity": "",
            "pfNaicsCode": "",
            "pfRegion": "",
            "pfSector": "",
            "pfSubAssetClass": "",
            "bloombergIndustryGroup": "",
            "bloombergIndustrySubGroup": "",
            "bloombergIndustrySector": "",
            "countryOfIssuance": "",
            "issueCurrency": "",
            "issuer": "",
            "riskCurrency": "",
            "putDate": "",
            "putPrice": "",
            "askPrice": 0,
            "highPrice": 0,
            "lowPrice": 0,
            "openPrice": 0,
            "volume": 0,
            "bidPrice": 0,
            "lastPrice": 0,
            "callDate": "",
            "callPrice": 0,
            "sid": 0
        });
    function updateData() {
        console.log(newBond);
        axios.put("http://localhost:5081/Bondcontroller/UpdateBond/"+newBond.sid+"", newBond).then((response) => {
            console.log(response);
            alert("Bond Updated");
            props.SetOpenUpdate(false);
            props.SetAllBondData({});
        })
    }
    useEffect(()=>{
        setNewBond(props.allBondData);
    },[props.allBondData]);
    return (
        <div>
            <Container sx={{ p: '10px', backgroundColor: "white" }}>
                <Grid container alignItems="center" rowSpacing={3}>
                    <Grid item xs={11} sm={11} md={11} lg={11} xl={11}>
                        <h2 style={{ textAlign: "center" }}>New Bond</h2>
                    </Grid>
                    <Grid item xs={1} sm={1} md={1} lg={1} xl={1} >
                        <button style={{ fontSize: "xx-large", background: "transparent", border: "none" }} onClick={() => props.SetOpenUpdate(false)}>X</button>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Security Description :</b> </label>
                        <input type='text' value={newBond.securityDescription} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, securityDescription: e.target.value }
                            })
                        }} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Security Name : </b></label>
                        <input type='text' value={newBond.securityName} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, securityName: e.target.value }
                            })
                        }} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Asset Type :</b></label>
                        <input type='text' value={newBond.assetType} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, assetType: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Investment Type :</b></label>
                        <input type='text' value={newBond.investmentType} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, investmentType: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Trading Factor :</b></label>
                        <input type='number' value={newBond.tradingFactor} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, tradingFactor: Number(e.target.value) }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Pricing Factor :</b></label>
                        <input type='number' value={newBond.pricingFactor} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, pricingFactor: Number(e.target.value) }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>ISIN :</b></label>
                        <input type='text' value={newBond.isin} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, isin: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bloomberg Ticker :</b></label>
                        <input type='text' value={newBond.bbgTicker} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, bbgTicker: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bloomberg Unique ID :</b></label>
                        <input type='text' value={newBond.bbgUniqueId} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, bbgUniqueId: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>CUSIP :</b></label>
                        <input type='text' value={newBond.cusip} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, cusip: e.target.value }
                            })
                        }} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>SEDOL :</b></label>
                        <input type='text' value={newBond.sedol} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, sedol: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>First Coupon Date :</b></label>
                        <input type='date' value={newBond.firstCouponDate} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, firstCouponDate: e.target.value }
                            })
                        }} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Coupon Cap :</b></label>
                        <input type='text' value={newBond.cap} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, cap: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Coupon Floor :</b></label>
                        <input type='text' value={newBond.floor} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, floor: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Coupon Frequency :</b></label>
                        <input type='number' value={newBond.couponFrequency} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, couponFrequency: Number(e.target.value) }
                            })
                        }} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Coupon Rate :</b></label>
                        <input type='number' value={newBond.coupon} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, coupon: Number(e.target.value) }
                            })
                        }} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Coupon Type :</b></label>
                        <input type='text' value={newBond.couponType} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, couponType: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Float Spread :</b></label>
                        <input type='text' value={newBond.spread} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, spread: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Is Callable :</b></label>
                        <input type='radio' name='isCallable' checked={newBond.callableFlag?true:false} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, callableFlag: true }
                            })
                        }}  ></input>
                        <label>Yes</label>
                        <input type='radio' name='isCallable' checked={newBond.callableFlag?false:true} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, callableFlag: false }
                            })
                        }}  ></input>
                        <label>NO</label>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Is Fix to Float :</b></label>
                        <input type='radio' name='isFixToFlat' checked={newBond.fixToFloatFlag?true:false} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, fixToFloatFlag: true }
                            })
                        }}  ></input>
                        <label>Yes</label>
                        <input type='radio' name='isFixToFlat' checked={newBond.fixToFloatFlag?false:true} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, fixToFloatFlag: false }
                            })
                        }}  ></input>
                        <label>NO</label>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Is Putable :</b></label>
                        <input type='radio' name='isPutable' checked={newBond.putableFlag?true:false} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, putableFlag: e.target.value }
                            })
                        }}></input>
                        <label>Yes</label>
                        <input type='radio' name='isPutable' checked={newBond.putableFlag?false:true} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, putableFlag: e.target.value }
                            })
                        }}  ></input>
                        <label>NO</label>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Issue Date :</b></label>
                        <input type='date' value={newBond.issueDate} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, issueDate: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Last Reset Date :</b></label>
                        <input type='date' value={newBond.lastResetDate} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, lastResetDate: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Maturity Date :</b></label>
                        <input type='date' value={newBond.maturity} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, maturity: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Maximum Call Notice Days :</b></label>
                        <input type='number' value={newBond.callNotificationMaxDays} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, callNotificationMaxDays: Number(e.target.value) }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Maximum Put Notice Days :</b></label>
                        <input type='number' value={newBond.putNotificationMaxDays} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, putNotificationMaxDays: Number(e.target.value) }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Penultimate Coupon Date :</b></label>
                        <input type='date' value={newBond.penultimateCouponDate} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, penultimateCouponDate: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Reset Frequency :</b></label>
                        <input type='text' value={newBond.resetFrequency} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, resetFrequency: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Has Position :</b></label>
                        <input type='radio' name='hasPosition' checked={newBond.hasPosition?true:false} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, hasPosition: true }
                            })
                        }} ></input>
                        <label>Yes</label>
                        <input type='radio' name='hasPosition' checked={newBond.hasPosition?false:true} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, hasPosition: false }
                            })
                        }} ></input>
                        <label>NO</label>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Duration :</b></label>
                        <input type='number' value={newBond.macaulayDuration} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, macaulayDuration: Number(e.target.value) }
                            })
                        }} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Volatility 30D :</b></label>
                        <input type='number' value={newBond._30dVolatility} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, _30dVolatility: Number(e.target.value) }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Volatility 90D :</b></label>
                        <input type='number' value={newBond._90dVolatility} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, _90dVolatility: Number(e.target.value) }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Convexity :</b></label>
                        <input type='number' value={newBond.convexity} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, convexity: Number(e.target.value) }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Average Volume 30D :</b></label>
                        <input type='number' value={newBond._30dayAverageVolume} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, _30dayAverageVolume: Number(e.target.value) }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Asset Class :</b></label>
                        <input type='text' value={newBond.pfAssetClass} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, pfAssetClass: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Country :</b></label>
                        <input type='text' value={newBond.pfCountry} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, pfCountry: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Credit Rating :</b></label>
                        <input type='text' value={newBond.pfCreditRating} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, pfCreditRating: e.target.value }
                            })
                        }} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Currency :</b></label>
                        <input type='text' value={newBond.pfCurrency} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, pfCurrency: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Instrument :</b></label>
                        <input type='text' value={newBond.pfInstrument} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, pfInstrument: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Liquidity Profile :</b></label>
                        <input type='text' value={newBond.pfLiquidityProfile} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, pfLiquidityProfile: e.target.value }
                            })
                        }} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Maturity :</b></label>
                        <input type='text' value={newBond.pfMaturity} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, pfMaturity: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF NAICS Code :</b></label>
                        <input type='text' value={newBond.pfNaicsCode} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, pfNaicsCode: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Region :</b></label>
                        <input type='text' value={newBond.pfRegion} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, pfRegion: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Sector :</b></label>
                        <input type='text' value={newBond.pfSector} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, pfSector: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Form PF Sub Asset Class :</b></label>
                        <input type='text' value={newBond.pfSubAssetClass} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, pfSubAssetClass: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bloomberg Industry Group :</b></label>
                        <input type='text' value={newBond.bloombergIndustryGroup} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, bloombergIndustryGroup: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bloomberg Industry Sub
                            Group :</b></label>
                        <input type='text' value={newBond.bloombergIndustrySubGroup} onChange={(e) => {
                            setNewBond(prevState => {
                                return { ...prevState, bloombergIndustrySubGroup: e.target.value }
                            })
                        }}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bloomberg Sector :</b></label>
                        <input type='text' value={newBond.bloombergIndustrySector} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, bloombergIndustrySector: e.target.value }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Issue Country :</b></label>
                        <input type='text' value={newBond.countryOfIssuance} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, countryOfIssuance: e.target.value }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Issue Currency :</b></label>
                        <input type='text' value={newBond.issueCurrency} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, issueCurrency: e.target.value }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Issuer :</b></label>
                        <input type='text' value={newBond.issuer} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, issuer: e.target.value }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Risk Currency :</b></label>
                        <input type='text' value={newBond.riskCurrency} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, riskCurrency: e.target.value }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Put Date :</b></label>
                        <input type='date' value={newBond.putDate} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, putDate: e.target.value }
                        })}} ></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Put Price :</b></label>
                        <input type='number' value={newBond.putPrice} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, putPrice: Number(e.target.value) }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Ask Price :</b></label>
                        <input type='number' value={newBond.askPrice} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, askPrice: Number(e.target.value) }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>High Price :</b></label>
                        <input type='number' value={newBond.highPrice} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, highPrice: Number(e.target.value) }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Low Price :</b></label>
                        <input type='number' value={newBond.lowPrice} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, lowPrice: Number(e.target.value) }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Open Price :</b></label>
                        <input type='number' value={newBond.openPrice} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, openPrice: Number(e.target.value) }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Volume :</b></label>
                        <input type='number' value={newBond.volume} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, volume: Number(e.target.value) }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Bid Price :</b></label>
                        <input type='number' value={newBond.bidPrice} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, bidPrice: Number(e.target.value) }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Last Price :</b></label>
                        <input type='number' value={newBond.lastPrice} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, lastPrice: Number(e.target.value) }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Call Date :</b></label>
                        <input type='date' value={newBond.callDate} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, callDate: e.target.value }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={3}>
                        <label><b>Call Price :</b></label>
                        <input type='number' value={newBond.callPrice} onChange={(e)=>{
                            setNewBond(prevState => {
                                return { ...prevState, callPrice: Number(e.target.value) }
                        })}}></input>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                        <Button variant='contained' onClick={updateData} fullWidth>Save</Button>
                    </Grid>
                </Grid>
            </Container>
        </div>
    )
}

export default UpdateBond
