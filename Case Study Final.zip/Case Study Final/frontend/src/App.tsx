import React from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import './App.css';
import Navbar from './Components/Navbar';
// import EquityBar from './Components/EquityBar';
import BondBar from './Components/BondBar';
import EquityBar from './Components/EquityBar';
import BondTable from './Components/AllBondTable';
import EquityTable from './Components/AllEquityTable';

function App() {
  return (
    <div>

      <BrowserRouter>
        <Navbar></Navbar>
        <br />
        <Routes>
          <Route path="/" element={<EquityBar/>}/>
          <Route path="/Equity" element={<EquityBar />} />
          <Route path="/Bond" element={<BondBar />} />
          <Route path="/BondTable" element={<BondTable />} />
          <Route path="/EquityTable" element={<EquityTable />} />
        </Routes>
      </BrowserRouter>
      {/* <BondTable/> */}
    </div>
  );
}

export default App;
